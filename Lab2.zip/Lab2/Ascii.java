import java.util.Scanner;

public class Labe {

	public static void main(String[] args) {
		char ch = 'a';
        int ascii = ch;
        
        int castAscii = (int) ch;
		
		System.out.println("ASCII value of " + ch + " is - " + castAscii);

	}

}
